Pardus için Ebeveyn Kontrolü Aracı
